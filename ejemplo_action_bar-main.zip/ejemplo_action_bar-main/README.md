Ejemplo de implementación de una ToolBar superior para una Actividad. Para implementar la ToolBar he seguido las siguientes guías:
 - Para el diseño:
   - https://m3.material.io/components/top-app-bar/overview
   - https://github.com/material-components/material-components-android/blob/master/docs/components/TopAppBar.md
 - Para su implementación en kotlin:
   - https://developer.android.com/develop/ui/views/components/appbar/setting-up
 - Para integrarlo con Navigation UI (que se asocie automáticamente a un gráfico de navegación)
   - https://developer.android.com/guide/navigation/integrations/ui?hl=es-419#Tie-navdrawer
 - Para mostrar el botón arriba: https://developer.android.com/guide/navigation/navigation-ui?hl=es-419 



