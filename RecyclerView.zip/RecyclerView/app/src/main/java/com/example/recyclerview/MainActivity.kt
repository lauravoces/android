package com.example.recyclerview

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.recyclerview.Adapter.MessageAdapter
import com.example.recyclerview.Model.Message
import com.mpd.pmdm.mensajesrecyclerview.data.AquiVanLosMensajes


class MainActivity : AppCompatActivity() {

    private val messageList = ArrayList<Message>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // dar ejemplos al RecyclerView
        val messageList = AquiVanLosMensajes.data
        // Si fuera necesario se agregaran mas mensajes
        val adapter = MessageAdapter(messageList)
        val rvPlanes: RecyclerView = findViewById(R.id.chatRecyclerView)
        rvPlanes.adapter = adapter
        rvPlanes.layoutManager = LinearLayoutManager(this)
    }
}

