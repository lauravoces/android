package com.example.recyclerview.Model

class Message(val authorName: String, val imgAuthor: Int, val text: String) {


}