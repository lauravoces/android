package com.example.practicanavegacion1.bombilla

interface InterruptorBombillaListener {
    fun onTurnOn()
    fun onTurnOff()


}