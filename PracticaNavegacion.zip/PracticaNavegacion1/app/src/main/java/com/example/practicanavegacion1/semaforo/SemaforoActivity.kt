package com.example.practicanavegacion1.semaforo

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

import com.example.practicanavegacion1.R
import com.example.practicanavegacion1.R.*
import com.example.practicanavegacion1.semaforo.model.semaforo
import com.example.practicanavegacion1.databinding.ActivityBombillaBinding
import com.example.practicanavegacion1.databinding.ActivitySemaforoBinding


class SemaforoActivity : AppCompatActivity(),BotonSemaforoListener {

     private lateinit var trafficLightFrameLayout: TextView
     private lateinit var changeColorButton: Button
     private lateinit var binding: ActivitySemaforoBinding
    val instancia = semaforo()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivitySemaforoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        trafficLightFrameLayout = findViewById(id.Color)
        changeColorButton = findViewById(id.button2)


        changeColorButton.setOnClickListener {
            instancia.avanzar()
            onColorChange(instancia.color)
        }
    }
    override fun onColorChange(color: Int) {
        trafficLightFrameLayout.setBackgroundColor(color)
    }

}