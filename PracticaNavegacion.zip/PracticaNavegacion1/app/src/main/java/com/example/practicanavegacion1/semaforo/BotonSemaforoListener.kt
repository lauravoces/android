package com.example.practicanavegacion1.semaforo

interface BotonSemaforoListener {

    fun onColorChange(color: Int)
}