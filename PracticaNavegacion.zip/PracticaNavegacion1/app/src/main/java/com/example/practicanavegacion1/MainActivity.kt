package com.example.practicanavegacion1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.example.practicanavegacion1.bombilla.BombillaActivity
import com.example.practicanavegacion1.semaforo.BotonSemaforoListener
import com.example.practicanavegacion1.semaforo.SemaforoActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val botonBombilla = findViewById<Button>(R.id.botonBombilla)

        botonBombilla.setOnClickListener {
            val intent = Intent(this, BombillaActivity::class.java)
            startActivity(intent)
        }

        val botonSemaforo = findViewById<Button>(R.id.botonSemaforo)

        botonSemaforo.setOnClickListener {
            val intent2 = Intent(this, SemaforoActivity::class.java)
            startActivity(intent2)
        }
    }

}