package com.example.practicanavegacion1.bombilla

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.example.practicanavegacion1.R
import com.example.practicanavegacion1.bombilla.model.bombilla
import com.example.practicanavegacion1.databinding.ActivityBombillaBinding

class BombillaActivity : AppCompatActivity(),InterruptorBombillaListener {

    private lateinit var binding: ActivityBombillaBinding
    private lateinit var button3: Button
    private lateinit var imageView2: ImageView
    private lateinit var button4: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityBombillaBinding.inflate(layoutInflater)
        setContentView(binding.root)


        imageView2 = findViewById(R.id.imagenView)
        button3 = findViewById(R.id.button3)
        button4 = findViewById(R.id.button4)
        val instancia = bombilla()

        button3.isEnabled=true
        button4.isEnabled=false

        button3.setOnClickListener {
            onTurnOn()
            instancia.encender()

        }

        button4.setOnClickListener{
            onTurnOff()
            instancia.apagar()
        }
    }

    override fun onTurnOn() {

        imageView2.setImageResource(R.drawable.encendida)
        button3.isEnabled=false
        button4.isEnabled=true
    }

    override fun onTurnOff() {
        imageView2.setImageResource((R.drawable.apagada))
        button3.isEnabled=true
        button4.isEnabled=false
    }
}
