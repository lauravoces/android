package com.example.practicanavegacion1.bombilla.model

class bombilla {
    private var encendida: Boolean = false
    fun encender() {
        encendida = true
    }

    fun apagar(){
        encendida = false
    }

    fun estaEncendida():Boolean{
        return encendida
    }



}