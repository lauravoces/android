package com.mpd.pmdm.examplenavigationlogin.model

data class Cita(val autor: String, val texto:String)