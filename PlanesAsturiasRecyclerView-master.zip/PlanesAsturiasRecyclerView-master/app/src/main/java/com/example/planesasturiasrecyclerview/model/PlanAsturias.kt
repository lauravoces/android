package com.example.planesasturiasrecyclerview.model

import androidx.annotation.DrawableRes

data class PlanAsturias(@DrawableRes val imgResourceId:Int, val descripcion:String)