
package com.example.composequadrant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
//import androidx.compose.ui.text.googlefonts.GoogleFont
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.composequadrant.ui.theme.ComposeCuadrantesTema

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContent {
            ComposeCuadrantesTema {
                // llamar a argumentos nombrados
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    //llamada a funcion fun--nombre
                    CuadradosTexto()
                }
            }
        }
    }
}
@Composable
// acordarme de poner el composable
fun CuadradosTexto() {
    //una columna, luego row, cada row dos elementos
    //si añado maxwidth me despreocupo de darle valor
    Column(Modifier.fillMaxWidth()) {
        //el weight de las row afecta a cuando ocupa la row, los 2 en conjunto
        Row(Modifier.weight(1F)) {
            ///en la llamada a la funcion metemos los elementos
            //que seran afectados por como esta configurada
            //fun ComposableInfo... blabla cada row son 2
            ConfiguracionCuadrantes(//1
                // Pillamos los strings desde values String xml
                // tambien puedes pasarlos directamente sin llamar
                //a R.string.nombredelstring
                titulo = stringResource(R.string.titulo1),
                descripcion = stringResource(R.string.descrip1),
                // Damos el bg usando COLOR
                backgroundColor = Color(0xFFEADDFF),
                //cada modificador afecta a cuando ancho ocupa este texto
                //siendo todos 1f ocuparan lo mismo.
                modificador = Modifier.weight(1f)
            )
            ConfiguracionCuadrantes(//2
                titulo = stringResource(R.string.titulo2),
                descripcion = stringResource(R.string.descrip2),
                backgroundColor = Color(0xFFD0BCFF),
                modificador = Modifier.weight(1f)
            )
        }

        Row(Modifier.weight(1F)) {//estos son los 2 de abajo
            ConfiguracionCuadrantes(
                titulo = stringResource(R.string.titulo3),
                descripcion = stringResource(R.string.descrip3),
                backgroundColor = Color(0xFFB69DF8),
                modificador = Modifier.weight(1f)
            )
            ConfiguracionCuadrantes(
                titulo = stringResource(R.string.titulo4),
                descripcion = stringResource(R.string.descrip4),
                backgroundColor = Color(0xFFF6EDFF),
                modificador = Modifier.weight(1f)
            )
        }
    }
}
@Composable
//esta duncion afecta al texto
//da basicamente los modificadores para la columna y fila
private fun ConfiguracionCuadrantes(
    titulo: String,
    descripcion: String,
    backgroundColor: Color,
    //esto en android esta bien hecho en java no tanto
    //esto da un warning pero lo he hecho para mi propia salud mental
    modificador: Modifier = Modifier
) {
    Column(
        modifier = modificador
            .fillMaxSize()
            .background(backgroundColor)
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            //lo que afecta al titulo - 1
            //afectada a los 4
            text = titulo,
            modifier = Modifier.padding(bottom = 16.dp),
            //fontweight hace referencia a que -gorda- es la fuente, normalmente se puede poner con Bold, en otros entornos tambien con porcentaje
            fontStyle = FontStyle.Italic,
            fontWeight = FontWeight.Bold
        )
        Text(
            //lo que afecta a la descripcion - 2
            //AFECTARA a las 4
            text = descripcion,
            fontWeight = FontWeight.ExtraLight,
            fontStyle = FontStyle.Italic,
            textAlign = TextAlign.Justify
        )
    }
}

@Preview(showBackground = true)
@Composable
fun ComposeQuadrantAppPreview() {
    ComposeCuadrantesTema {
        CuadradosTexto()
    }
}
