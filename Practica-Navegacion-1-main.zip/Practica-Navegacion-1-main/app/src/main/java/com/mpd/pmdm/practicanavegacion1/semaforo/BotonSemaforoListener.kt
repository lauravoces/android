package com.mpd.pmdm.practicanavegacion1.semaforo

interface BotonSemaforoListener {
    fun onClickedButton()
}