package com.lvgpmdm.rgbcolors

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.textfield.TextInputLayout


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val colorFinal: Button = findViewById(R.id.buttonColor)
        colorFinal.setOnClickListener {
           coloFinalAqui()
        }
    }
    private fun coloFinalAqui() {
        val rojo: TextInputLayout = findViewById(R.id.rojoText)
        val verde: TextInputLayout = findViewById(R.id.verdeText)
        val azul: TextInputLayout = findViewById(R.id.azulText)
        val textViewColor: TextView = findViewById(R.id.colorFinal)

        val rojoValue = rojo.editText?.text.toString()
        val verdeValue = verde.editText?.text.toString()
        val azulValue = azul.editText?.text.toString()
        if (rojoValue.length < 2 || verdeValue.length < 2 || azulValue.length < 2) {
            // Mostrar un Toast de error
            Toast.makeText(this, "Cada componente del color debe tener al menos 2 caracteres", Toast.LENGTH_SHORT).show()
            return
        }
        //Acordarme de esto
        textViewColor.visibility = View.VISIBLE
        textViewColor.setBackgroundColor(Color.parseColor("#"+rojoValue+verdeValue+azulValue))


    }



}