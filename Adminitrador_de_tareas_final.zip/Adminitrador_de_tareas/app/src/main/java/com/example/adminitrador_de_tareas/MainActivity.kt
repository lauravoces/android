package com.example.adminitrador_de_tareas

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import com.example.adminitrador_de_tareas.ui.theme.AdminEstilo
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AdminEstilo {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    ComposeAdministrador("All tasks completed","Nice Work!")
                }
            }
        }
    }
}

@Composable
fun ComposeAdministrador(textoPrincipal: String, textoSecundario: String, modifier: Modifier = Modifier) {
    androidx.compose.foundation.layout.Column (horizontalAlignment = Alignment.CenterHorizontally,
verticalArrangement = Arrangement.Center,modifier = modifier.padding(8.dp)){
        Image (
            painter = painterResource(id = R.drawable.ic_task_completed),
            contentDescription = "imagen"
        )
        Text(
            //primer texto
            text = textoPrincipal,
            textAlign = TextAlign.Center,
            fontWeight = FontWeight.Bold,
            modifier =  Modifier
                .padding(top = 24.dp, bottom = 8.dp)
        )
        Text(
            //segundo texto
            text = textoSecundario,
            fontSize = 16.sp,
            textAlign = TextAlign.Center,
        )
    }
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    AdminEstilo {
        ComposeAdministrador("All tasks completed","Nice Work!")
    }
}